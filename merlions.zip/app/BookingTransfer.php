<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookingTransfer extends Model
{
    protected $table = 'booking_transfer';
    public $timestamps = false;
}
